﻿namespace winPEAS._3rdParty.BouncyCastle.asn1
{
    public interface IAsn1Convertible
	{
		Asn1Object ToAsn1Object();
	}
}
